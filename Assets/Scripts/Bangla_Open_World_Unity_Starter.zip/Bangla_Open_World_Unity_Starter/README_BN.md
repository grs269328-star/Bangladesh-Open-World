# বাংলাদেশ ওপেন ওয়ার্ল্ড — Unity Android Multiplayer Starter

এটি একটি **প্রথম playable prototype starter source**। এটি সম্পূর্ণ GTA-ধাঁচের গেম নয়; Unity-তে একটি ছোট শহরের scene, third-person player এবং online Host/Client movement দাঁড় করানোর ভিত্তি।

## লক্ষ্য
- Android + Unity
- কাল্পনিক বাংলাদেশি শহর
- Third-person camera
- Online multiplayer (Unity Netcode for GameObjects)
- প্রথম prototype: player চলাফেরা, Host/Client join, basic scene

## যা লাগবে
- Unity Hub এবং Unity 2022.3 LTS বা Unity 6 (একটি সংস্করণ বেছে নিয়ে একই সংস্করণে কাজ করুন)
- Android Build Support, Android SDK/NDK ও OpenJDK (Unity Hub থেকে)
- Package Manager থেকে:
  - `com.unity.netcode.gameobjects`
  - `com.unity.transport`

## Unity-তে সেটআপ
1. Unity-তে 3D (Core) project খুলুন।
2. এই ZIP-এর `Assets/Scripts` ফোল্ডারটি আপনার project-এর `Assets` ফোল্ডারে কপি করুন।
3. Package Manager-এ উপরের দুটি package ইনস্টল করুন।
4. Scene-এ একটি Plane বানান (নাম `Ground`, Position `0,0,0`, Scale `10,1,10`)।
5. একটি Capsule বানান (নাম `Player`), Position `0,1,0`; এতে `CharacterController`, `NetworkObject`, `NetworkTransform`, `NetworkPlayerController` যোগ করুন।
6. `NetworkTransform` server-authoritative রাখুন (default)।
7. Scene-এ একটি আলাদা `Main Camera` রাখুন (Player prefab-এর child করবেন না)। এতে `ThirdPersonCamera` যোগ করুন। Camera script নিজে local player-কে অনুসরণ করবে।
8. `NetworkManager` GameObject বানান। এতে `NetworkManager` এবং `UnityTransport` যোগ করুন।
9. NetworkManager-এর **Player Prefab** slot-এ Player prefab দিন। Player-কে Project window-এ drag করে prefab বানিয়ে নিন।
10. `NetworkManager`-এ `NetworkBootstrapUI` যোগ করুন।
11. Project Settings → Player → Active Input Handling-এ `Both` অথবা `Input Manager (Old)` নির্বাচন করুন (এই starter keyboard input-এর জন্য পুরোনো Input Manager ব্যবহার করে)।
11. Scene-টি Build Settings / Build Profiles-এ যোগ করুন।

## কীভাবে চালাবেন
- Editor-এ Play চাপুন; ছোট Host/Client UI দেখা যাবে।
- একই LAN-এ দুটি build চালিয়ে Host ও Client দিয়ে পরীক্ষা করুন। Router/firewall/NAT-এর কারণে ইন্টারনেটের মাধ্যমে দূরের খেলোয়াড়ে সরাসরি সংযোগ নাও হতে পারে।
- Android-এ পরীক্ষা করতে Build Profiles থেকে Android নির্বাচন করে Build করুন।

## গুরুত্বপূর্ণ নোট
- এই starter-এ keyboard input (`WASD` / arrow keys) দিয়ে movement পরীক্ষা করা যায়। Android touch joystick, login, matchmaking, relay/lobby, voice chat, save system, vehicle system ও anti-cheat এখনো যোগ করা হয়নি।
- প্রকৃত internet multiplayer-এর জন্য Unity Relay/Lobby বা নিজস্ব dedicated server দরকার হতে পারে। শুধু Host/Client UI থাকলেই public internet matchmaking তৈরি হয় না।
- গেমে বাস্তব GTA assets, নাম, logo বা copyrighted content কপি করবেন না; নিজস্ব assets ব্যবহার করুন।


## নতুন: বাংলাদেশের গ্রামের Blockout
1. Scene-এ Empty GameObject তৈরি করে নাম দিন `VillageWorld`।
2. এতে `BangladeshVillageBuilder` script যোগ করুন।
3. Play চাপলে রাস্তা, বাড়ি, বাজার, পুকুর, মসজিদ ও গাছের একটি সাধারণ গ্রাম তৈরি হবে।
4. এটি placeholder geometry; পরে নিজস্ব সুন্দর 3D model, texture, বাংলা সাইনবোর্ড, আলো, শব্দ ও optimization যোগ করতে হবে।
5. `Player` spawn position আপাতত রাস্তার পাশে (0, 1, -15) রাখুন এবং গ্রামের রাস্তার দিকে মুখ করান।

**নোট:** এটি একটি প্রাথমিক blockout, বাস্তব বাংলাদেশের নিখুঁত মডেল নয়। Android-এ performance যাচাই করে গাছ/বাড়ির সংখ্যা কমানো-বাড়ানো যাবে।


## সম্পূর্ণ বাংলা ভাষার UI
- প্রোটোটাইপের Host/Client পরীক্ষার প্যানেলের লেখা বাংলায় করা হয়েছে।
- Unity-এর পুরোনো `OnGUI` ফন্টে বাংলা অক্ষর ঠিকমতো নাও দেখা যেতে পারে। পূর্ণ বাংলা UI বানানোর সময় TextMeshPro ব্যবহার করুন।
- বাংলা অক্ষরের জন্য বাংলা glyph-সহ Unicode font (যেমন Noto Sans Bengali) থেকে TextMeshPro Font Asset তৈরি করে সব UI Text-এ সেট করুন।
- মেনু, চরিত্র তৈরি, মিশন, দোকান, সেটিংস, সতর্কবার্তা ও Multiplayer বার্তা—সব বাংলায় রাখুন।
