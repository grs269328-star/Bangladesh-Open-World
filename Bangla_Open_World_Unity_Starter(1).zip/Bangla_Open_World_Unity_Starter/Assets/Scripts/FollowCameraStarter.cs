using UnityEngine;

public class FollowCameraStarter : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0f, 4f, -6f);
    [SerializeField] private float smooth = 6f;

    private void LateUpdate()
    {
        if (target == null) return;
        Vector3 wanted = target.position + target.TransformDirection(offset);
        transform.position = Vector3.Lerp(transform.position, wanted, smooth * Time.deltaTime);
        transform.LookAt(target.position + Vector3.up * 1.4f);
    }
}
