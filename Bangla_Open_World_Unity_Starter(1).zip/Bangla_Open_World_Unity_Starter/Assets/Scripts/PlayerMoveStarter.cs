using UnityEngine;

// প্রাথমিক কিবোর্ড/টাচ ইনপুট-সক্ষম চলাচলের নমুনা।
// প্রকৃত মোবাইল UI ও নেটওয়ার্ক ইনপুট পরে যুক্ত করতে হবে।
public class PlayerMoveStarter : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 4f;

    private void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        Vector3 move = new Vector3(x, 0f, z);
        if (move.sqrMagnitude > 1f) move.Normalize();

        transform.Translate(move * moveSpeed * Time.deltaTime, Space.World);

        if (move.sqrMagnitude > 0.001f)
            transform.forward = Vector3.Slerp(transform.forward, move, 12f * Time.deltaTime);
    }
}
