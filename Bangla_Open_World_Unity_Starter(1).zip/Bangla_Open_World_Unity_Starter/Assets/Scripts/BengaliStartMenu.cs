using UnityEngine;

// প্রাথমিক বাংলা মেনু টেক্সটের নমুনা; UI Canvas/Button পরে তৈরি করতে হবে।
public class BengaliStartMenu : MonoBehaviour
{
    public string gameTitle = "বাংলাদেশ ওপেন ওয়ার্ল্ড";
    public string startLabel = "খেলা শুরু";
    public string settingsLabel = "সেটিংস";
    public string exitLabel = "বের হও";
}
